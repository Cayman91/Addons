if( GetLocale() ~= "frFR" ) then
	return
end

ArenaIdentLocals = setmetatable({

}, {__index = ArenaIdentLocals})

