ArenaIdentLocals = {	
	["Arena Preparation"] = "Arena Preparation",
	["The Arena battle has begun!"] = "The Arena battle has begun!",

	["Only saving people who you have seen within the last %d days now."] = "Only saving people who you have seen within the last %d days now.",
	["/ai prune <days> - Set how many days players should be saved before being removed, use 0 to disable."] = "/ai prune <days> - Set how many days players should be saved before being removed, use 0 to disable.",
}