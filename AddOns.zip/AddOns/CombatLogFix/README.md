CombatLogFix
============
Keeps your CombatLog from breaking and therefore keeps all addons that use the CombatLog intact, e.g:
PartyAbilityBars, LoseControl, MSBT, SCT, InterruptBar, SpellAlerter, Afflicted and many more
